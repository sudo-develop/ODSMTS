package com.ODSMTS.Controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
